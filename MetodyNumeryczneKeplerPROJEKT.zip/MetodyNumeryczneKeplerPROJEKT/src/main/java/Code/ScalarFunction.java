package Code;

public interface ScalarFunction {
    public abstract double getF(double M, double e, double x);
}
